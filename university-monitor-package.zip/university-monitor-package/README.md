# 大学招生信息监控系统 - 集成指南

## 📦 项目概述

本系统用于自动监控全球顶尖大学官网的招生/录取信息，使用 DeepSeek AI 提取关键内容，并自动发布到论坛。

---

## 📁 项目结构说明

```
university-monitor/
│
├── 📂 backend/                    # Python 后端（监控脚本）
│   ├── src/
│   │   ├── main.py               # 主程序入口
│   │   ├── scraper.py            # 爬虫模块
│   │   ├── processor.py          # DeepSeek 信息处理
│   │   ├── publisher.py          # Supabase 发布模块
│   │   ├── database.py           # SQLite 本地数据库
│   │   └── utils.py              # 工具函数
│   ├── config/
│   │   └── universities.yaml     # 大学配置
│   ├── requirements.txt          # Python 依赖
│   └── .env.example              # 环境变量模板
│
├── 📂 frontend/                   # React 前端（管理界面）
│   ├── pages/
│   │   ├── MonitorDashboard.jsx  # 监控总览
│   │   ├── PostManager.jsx       # 帖子管理
│   │   ├── ExecutionLogs.jsx     # 执行日志
│   │   ├── ConfigManager.jsx     # 配置管理
│   │   ├── KeywordManager.jsx    # 关键词管理
│   │   └── AdminLayout.jsx       # 布局组件
│   ├── components/
│   │   └── StatCard.jsx          # 统计卡片
│   └── lib/
│       └── monitorApi.js         # API 封装
│
├── 📂 supabase/                   # 数据库脚本
│   └── tables.sql                # 建表 SQL
│
├── 📂 github-actions/             # 自动化部署
│   └── monitor.yml               # GitHub Actions 工作流
│
└── README.md                      # 本文档
```

---

## 🚀 集成步骤总览

```
步骤 1: Supabase 数据库设置
    ↓
步骤 2: 后端脚本部署（GitHub Actions 或自有服务器）
    ↓
步骤 3: 前端组件集成到论坛
    ↓
步骤 4: 配置环境变量
    ↓
步骤 5: 测试运行
```

---

## 步骤 1: Supabase 数据库设置

### 1.1 登录 Supabase Dashboard

访问 https://supabase.com/dashboard，进入您的项目。

### 1.2 执行建表 SQL

在 **SQL Editor** 中执行 `supabase/tables.sql` 文件中的内容：

```sql
-- 1. 分类表
CREATE TABLE IF NOT EXISTS categories (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    slug TEXT UNIQUE NOT NULL
);

-- 2. 插入默认分类
INSERT INTO categories (name, slug) VALUES
    ('招生信息', 'admissions'),
    ('录取通知', 'enrollment'),
    ('申请截止', 'deadlines'),
    ('奖学金', 'scholarships')
ON CONFLICT DO NOTHING;

-- 3. 帖子表
CREATE TABLE IF NOT EXISTS posts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    category_id UUID REFERENCES categories(id),
    author_id UUID,
    source_url TEXT,
    source_university TEXT,
    info_type TEXT,
    degree_level TEXT,
    is_auto_published BOOLEAN DEFAULT FALSE,
    view_count INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. 监控大学配置表
CREATE TABLE IF NOT EXISTS monitor_universities (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    country TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. 监控页面表
CREATE TABLE IF NOT EXISTS monitor_pages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    university_id UUID REFERENCES monitor_universities(id) ON DELETE CASCADE,
    url TEXT NOT NULL,
    page_type TEXT DEFAULT 'admission',
    degree_level TEXT DEFAULT 'all',
    is_active BOOLEAN DEFAULT TRUE,
    last_checked_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. 搜索关键词表
CREATE TABLE IF NOT EXISTS monitor_keywords (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    keyword TEXT NOT NULL,
    category TEXT DEFAULT 'general',
    language TEXT DEFAULT 'en',
    weight REAL DEFAULT 1.0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. 执行日志表
CREATE TABLE IF NOT EXISTS execution_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    run_time TIMESTAMPTZ DEFAULT NOW(),
    universities_processed INTEGER DEFAULT 0,
    posts_published INTEGER DEFAULT 0,
    errors TEXT,
    status TEXT DEFAULT 'success'
);

-- 8. 插入默认关键词
INSERT INTO monitor_keywords (keyword, category, language, weight) VALUES
    ('admission', 'admission', 'en', 2.0),
    ('application', 'admission', 'en', 1.5),
    ('enrollment', 'enrollment', 'en', 2.0),
    ('deadline', 'deadline', 'en', 2.0),
    ('scholarship', 'scholarship', 'en', 2.0),
    ('招生', 'admission', 'zh', 2.0),
    ('录取', 'enrollment', 'zh', 2.0),
    ('申请', 'admission', 'zh', 1.5),
    ('截止', 'deadline', 'zh', 2.0),
    ('奖学金', 'scholarship', 'zh', 2.0)
ON CONFLICT DO NOTHING;
```

### 1.3 创建机器人用户

1. 进入 **Authentication → Users**
2. 点击 **Add user → Create new user**
3. 填写邮箱（如 `monitor-bot@yourforum.com`）和密码
4. 创建后，复制该用户的 **UUID**

### 1.4 获取 API 凭证

在 **Settings → API** 中获取：
- **Project URL**: `https://xxx.supabase.co`
- **Service Role Key**: `eyJhbGciOiJIUzI1NiIsInR5cCI6...`（用于后端）

---

## 步骤 2: 后端脚本部署

### 方案 A: GitHub Actions（推荐，免费）

#### 2.1 创建 GitHub 仓库

1. 在 GitHub 创建新仓库（如 `university-monitor`）
2. 上传 `backend/` 目录下的所有文件

#### 2.2 配置 GitHub Secrets

在仓库 **Settings → Secrets and variables → Actions** 中添加：

| Secret 名称 | 值 |
|------------|-----|
| `DEEPSEEK_API_KEY` | 您的 DeepSeek API Key |
| `SUPABASE_URL` | Supabase Project URL |
| `SUPABASE_KEY` | Supabase Service Role Key |
| `BOT_USER_ID` | 机器人用户 UUID |

#### 2.3 添加 GitHub Actions 工作流

将 `github-actions/monitor.yml` 复制到仓库的 `.github/workflows/` 目录。

工作流会自动：
- 每天 8:00 和 20:00（北京时间）运行
- 爬取大学网站 → DeepSeek 处理 → 发布到论坛

### 方案 B: 自有服务器

```bash
# 1. 安装依赖
cd backend
pip install -r requirements.txt

# 2. 配置环境变量
cp .env.example .env
# 编辑 .env 填写配置

# 3. 设置定时任务（crontab）
crontab -e
# 添加：
0 8,20 * * * cd /path/to/backend && python src/main.py
```

---

## 步骤 3: 前端组件集成到论坛

### 3.1 复制文件到论坛项目

将以下文件复制到您的论坛项目：

```
前端文件                          → 论坛项目目标位置
─────────────────────────────────────────────────────
frontend/pages/*.jsx             → src/pages/admin/
frontend/components/admin/*.jsx  → src/components/admin/
frontend/lib/monitorApi.js       → src/lib/
```

### 3.2 修改 API 导入路径

编辑 `monitorApi.js`，修改第一行：

```javascript
// 修改前
import { supabase } from './supabase';

// 修改后（使用您论坛项目的 supabase 客户端路径）
import { supabase } from '../path/to/your/supabaseClient';
```

### 3.3 添加路由

在您论坛的路由配置文件中添加：

```jsx
// App.jsx 或 router.jsx

import AdminLayout from './pages/admin/AdminLayout';
import MonitorDashboard from './pages/admin/MonitorDashboard';
import PostManager from './pages/admin/PostManager';
import ExecutionLogs from './pages/admin/ExecutionLogs';
import ConfigManager from './pages/admin/ConfigManager';
import KeywordManager from './pages/admin/KeywordManager';

// 在 Routes 中添加
<Route path="/admin/monitor" element={<AdminLayout />}>
  <Route index element={<MonitorDashboard />} />
  <Route path="posts" element={<PostManager />} />
  <Route path="logs" element={<ExecutionLogs />} />
  <Route path="config" element={<ConfigManager />} />
  <Route path="keywords" element={<KeywordManager />} />
</Route>
```

### 3.4 添加导航入口

在论坛导航栏添加链接：

```jsx
<Link to="/admin/monitor">监控管理</Link>
```

---

## 步骤 4: 配置环境变量

### 4.1 DeepSeek API Key

1. 访问 https://platform.deepseek.com/
2. 注册并获取 API Key
3. 免费层：每天 100 次请求

### 4.2 完整环境变量清单

| 变量名 | 获取位置 | 用途 |
|--------|---------|------|
| `DEEPSEEK_API_KEY` | DeepSeek 平台 | LLM 信息提取 |
| `SUPABASE_URL` | Supabase Dashboard | 数据库连接 |
| `SUPABASE_KEY` | Supabase Dashboard（Service Role） | 后端发布帖子 |
| `BOT_USER_ID` | Supabase Auth | 机器人用户 UUID |

---

## 步骤 5: 测试运行

### 5.1 本地测试后端

```bash
cd backend

# 安装依赖
pip install -r requirements.txt

# 配置环境变量
cp .env.example .env
# 编辑 .env

# 测试模式（不实际发布）
python src/main.py --dry-run
```

### 5.2 测试前端

启动论坛项目，访问 `/admin/monitor` 查看管理界面。

---

## 📊 功能清单

| 功能 | 页面 | 说明 |
|------|------|------|
| 监控总览 | `/admin/monitor` | 统计卡片、趋势图、手动触发 |
| 帖子管理 | `/admin/monitor/posts` | 搜索、筛选、查看、删除 |
| 执行日志 | `/admin/monitor/logs` | 历史记录、成功率统计 |
| 配置管理 | `/admin/monitor/config` | 添加/删除大学和页面 |
| 关键词管理 | `/admin/monitor/keywords` | 管理搜索关键词 |

---

## 🔧 常见问题

### Q: 爬虫被网站封禁怎么办？

A: 
- 增加 `request_delay`（默认 5 秒）
- 使用代理 IP 池
- 降低监控频率

### Q: DeepSeek API 额度不够？

A:
- 免费层每天 100 次请求
- 可升级付费版，费用极低（约 ¥1/百万 token）

### Q: 帖子发布失败？

A: 检查：
- Supabase Service Role Key 是否正确
- `BOT_USER_ID` 是否有效
- 数据库表是否正确创建

---

## 📞 技术支持

如有问题，请检查：
1. 环境变量是否正确配置
2. Supabase 表是否正确创建
3. GitHub Actions 日志是否报错

---

*文档版本: v1.0*
*更新日期: 2025-05-11*
